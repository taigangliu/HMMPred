import numpy as np
import os
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn import metrics
from sklearn import svm
from sklearn.metrics import roc_curve, auc
import math
from sklearn.model_selection import GridSearchCV, LeaveOneOut, cross_val_score, KFold


def readFileNumber(path):
    fileNum = len([name for name in os.listdir(path) if os.path.isfile(os.path.join(path, name))])
    return fileNum


def get_matrix_lieave20(matrix):
    feature_matrix = matrix.sum(axis=0) / matrix.shape[0]
    return feature_matrix


def Auto_Cov(matrix, g):
    feature_matrix = []
    for k in range(g, g + 1):
        for j in range(20):
            sum = 0
            sum1 = 0
            for n in range(matrix.shape[0]):
                sum += (matrix[n, j])
            ave0 = sum / matrix.shape[0]
            for i in range(matrix.shape[0] - k):
                sum1 += ((matrix[i, j] - ave0) * (matrix[i + k, j] - ave0))
            ave1 = sum1 / (matrix.shape[0] - k)
            feature_matrix.append(ave1)
    return np.array(feature_matrix)


def Cross_Cov(matrix, g):
    feature_matrix = []
    for k in range(g, g + 1):
        for j in range(20):
            for n in range(20):
                sum0 = 0
                sum1 = 0
                sum2 = 0
                if (n == j):
                    continue
                else:
                    for a in range(matrix.shape[0]):
                        sum0 += float(matrix[a, j])
                    ave0 = sum0 / matrix.shape[0]
                    for b in range(matrix.shape[0]):
                        sum1 += float(matrix[b, n])
                    ave1 = sum1 / matrix.shape[0]
                    for i in range(matrix.shape[0] - k):
                        sum2 += ((matrix[i, j] - ave0) * (matrix[i + k, n] - ave1))
                    ave2 = sum2 / (matrix.shape[0] - k)
                    feature_matrix.append(ave2)
    return np.array(feature_matrix)


def useMatrix(matrixfile, style):
    matrixfir = np.loadtxt(matrixfile, dtype=np.str)
    if style in ['pssm', 'pspm', 'pssm-sequence', 'pspm-sequence']:
        matrixlast = np.array(matrixfir)
        if style == 'pssm':
            return matrixlast[:, 1:21]
        elif style == 'pspm':
            return matrixlast[:, 21:41]
        elif style == 'pssm-sequence':
            return matrixlast[:, 1:21], matrixlast[:, 0]
        elif style == 'pspm-sequence':
            return matrixlast[:, 21:41], matrixlast[:, 0]

    elif style in ['hmm', 'hmm-sequence']:
        matrixlast = np.array(matrixfir)
        if style == "hmm":
            return matrixlast[:, 2:matrixlast.shape[1]]
        else:
            return matrixlast[:, 2:matrixlast.shape[1]], matrixlast[:, 0]


def biaozhunhua(matrix, style):
    if style == "pssm":
        matrix = matrix.astype(np.float)
        matrix = 1 / (1 + np.exp(- matrix))
    elif style == "pspm":
        matrix = matrix.astype(np.float)
        matrix = matrix / 100
    elif style == "hmm":
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if matrix[i][j] == '*':
                    matrix[i][j] = 0
                else:
                    a = (-0.001) * eval(matrix[i][j])
                    matrix[i][j] = 2 ** a
        matrix = matrix.astype(float)
    return matrix


def featureMatrix_Lieave(DIR):
    fileNum = readFileNumber(DIR)
    featureMatrix = np.zeros((fileNum, 20))
    for k in range(1, fileNum + 1):
        matrix = useMatrix(DIR + "/" + str(k) + ".txt", 'hmm')
        matrix = biaozhunhua(matrix, 'hmm')
        featureMatrix[k - 1, :] = get_matrix_lieave20(matrix)
    return featureMatrix


def featureMatrix_Auto(DIR, i):
    fileNum = readFileNumber(DIR)
    featureMatrix = np.zeros((fileNum, 20))
    for k in range(1, fileNum + 1):
        matrix = useMatrix(DIR + "/" + str(k) + ".txt", 'hmm')
        matrix = biaozhunhua(matrix, 'hmm')
        featureMatrix[k - 1, :] = Auto_Cov(matrix, i)
    return featureMatrix


def featureMatrix_Cross(DIR, i):
    fileNum = readFileNumber(DIR)
    featureMatrix = np.zeros((fileNum, 380))
    for k in range(1, fileNum + 1):
        matrix = useMatrix(DIR + "/" + str(k) + ".txt", 'hmm')
        matrix = biaozhunhua(matrix, 'hmm')
        featureMatrix[k - 1, :] = Cross_Cov(matrix, i)
    return featureMatrix


def GridSearch_svm(X, y, i):
    svm_clf = svm.SVC(probability=True, kernel='rbf')
    parameters = {
        'C': np.logspace(-8, 12, 21, base=2),
        'gamma': np.logspace(-8, 12, 21, base=2)

    }
    grid = GridSearchCV(svm_clf, parameters, cv=i)
    grid.fit(X, y)

    best_clf_SVM = grid.best_estimator_
    best_params_ = grid.best_params_
    print("SVM " + str(i) + "fold best parameter：", best_params_)
    best_score = grid.best_score_
    print("SVM " + str(i) + "fold best accuracy：", best_score)
    return best_clf_SVM


def k_fold_SVM(best_clf, X, y, i):
    y_pred_list = []
    y_test_list = []
    y_score_list = []
    skf = StratifiedKFold(n_splits=i)
    for train, test in skf.split(X, y):
        print("X.shape=", X.shape)
        print("y.shape=", y.shape)
        best_clf.fit(X[train], y[train])
        y_pred = best_clf.predict(X[test])
        y_score = best_clf.predict_proba(X[test])
        y_pred_list.extend(y_pred)
        y_test_list.extend(y[test])
        y_score_list.extend(y_score)

    y_pred_list = np.array(y_pred_list)
    y_test_list = np.array(y_test_list)
    y_score_list = np.array(y_score_list)

    confusion = metrics.confusion_matrix(y_test_list, y_pred_list)
    TP = confusion[1, 1]
    TN = confusion[0, 0]
    FP = confusion[0, 1]
    FN = confusion[1, 0]

    accuracy = (TP + TN) / float(TP + TN + FN + FP)
    print("\nSVM " + str(i) + "fold Accuracy:", accuracy)

    recall = TP / float(TP + FN)
    Sensitivity = TP / float(TP + FN)
    print("SVM " + str(i) + "fold Sensitivity:", Sensitivity)

    specificity = TN / float(TN + FP)
    print("SVM " + str(i) + "fold Specificity:", specificity)

    precision = TP / float(TP + FP)
    print("SVM " + str(i) + "fold Precision：", precision)

    print("SVM " + str(i) + "fold F1", (2 * TP) / float(2 * TP + FP + FN))

    MCC = (TP * TN - FP * FN) / (math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)))
    print("SVM " + str(i) + "fold MCC：", MCC)

    fpr_kfold, tpr_kfold, thresholds = roc_curve(y_test_list, y_score_list[:, 1])
    roc_auc_kfold = auc(fpr_kfold, tpr_kfold)
    print("SVM " + str(i) + "fold AUC：", roc_auc_kfold)


def LOO_SVM(best_clf, X, y):
    loo = LeaveOneOut()
    y_pred_list = []
    y_test_list = []
    y_score_list = []
    for train, test in loo.split(X, y):
        best_clf.fit(X[train], y[train])
        y_pred = best_clf.predict(X[test])
        y_score = best_clf.predict_proba(X[test])
        y_pred_list.append(y_pred[0])
        y_test_list.append(y[test][0])
        y_score_list.append(y_score[0])

    y_score_list = np.array(y_score_list)
    confusion = metrics.confusion_matrix(y_test_list, y_pred_list)
    TP = confusion[1, 1]
    TN = confusion[0, 0]
    FP = confusion[0, 1]
    FN = confusion[1, 0]

    accuracy = (TP + TN) / float(TP + TN + FN + FP)
    print("\nSVM jackknifeCV Accuracy:", accuracy)

    recall = TP / float(TP + FN)
    Sensitivity = TP / float(TP + FN)
    print("SVM jackknifeCV Sensitivity:", Sensitivity)

    specificity = TN / float(TN + FP)
    print("SVM jackknifeCV Specificity:", specificity)

    precision = TP / float(TP + FP)
    print("SVM jackknifeCV Precision：", precision)

    print("SVM jackknifeCV F1:", (2 * TP) / float(2 * TP + FP + FN))

    MCC = (TP * TN - FP * FN) / (math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)))
    print("SVM jackknifeCV MCC：", MCC)

    fpr_jackknife, tpr_jackknife, thresholds = roc_curve(y_test_list, y_score_list[:, 1])
    roc_auc_jackknife = auc(fpr_jackknife, tpr_jackknife)
    print("SVM jackknifeCV AUC：", roc_auc_jackknife)


def Acc_indend_SVM(best_clf, X, y, X2, y2):
    best_clf.fit(X, y)
    y_pred2 = best_clf.predict(X2)
    y_score2 = best_clf.predict_proba(X2)
    confusion = metrics.confusion_matrix(y2, y_pred2)
    TP = confusion[1, 1]
    TN = confusion[0, 0]
    FP = confusion[0, 1]
    FN = confusion[1, 0]

    accuracy_inden = (TP + TN) / float(TP + TN + FN + FP)
    print("\nSVM independent test Accuracy:", accuracy_inden)

    recall_inden = TP / float(TP + FN)
    Sensitivity_inden = TP / float(TP + FN)
    print("SVM independent test Sensitivity:", Sensitivity_inden)

    specificity_inden = TN / float(TN + FP)
    print("SVM independent test Specificity:", specificity_inden)

    precision_inden = TP / float(TP + FP)
    print("SVM independent test Precision：", precision_inden)

    F1_inden = (2 * TP) / float(2 * TP + FP + FN)
    print("SVM independent test F1:", F1_inden)

    MCC_inden = (TP * TN - FP * FN) / (math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)))
    print("SVM independent test MCC：", MCC_inden)

    fpr_inden, tpr_inden, thresholds_inden = roc_curve(y2, y_score2[:, 1])
    roc_auc_inden = auc(fpr_inden, tpr_inden)
    print("SVM independent test AUC：", roc_auc_inden)


def main():
    x11 = featureMatrix_Auto("positive1_qian22lie", 2)
    x22 = featureMatrix_Auto("negative1_qian22lie", 2)
    X11 = np.vstack((x11, x22))

    x111 = featureMatrix_Cross("positive1_qian22lie", 2)
    x222 = featureMatrix_Cross("negative1_qian22lie", 2)
    X111 = np.vstack((x111, x222))

    X_Bench = np.hstack((X11, X111))

    y1 = [1 for i in range(x11.shape[0])]
    y1.extend([0 for i in range(x22.shape[0])])
    y1 = np.array(y1)

    best_model_SVM = GridSearch_svm(X_Bench, y1, 10)

    K_fold_svm = k_fold_SVM(best_model_SVM, X_Bench, y1, 10)

    LOO_svm = LOO_SVM(best_model_SVM, X_Bench, y1)


main()
